#### © Select your language
  [![English](https://img.shields.io/badge/Select-Sinhala-red.svg)](https://github.com/xneon2/Hashzi-X/blob/main/README.md)
  [![Sinhala](https://img.shields.io/badge/Select-English-green.svg)](https://github.com/xneon2/Hashzi-X/blob/main/README-SI.md)

![logo](https://telegra.ph/file/e8f3e419b3dafe9fe8153.jpg)
<h1 align="center"><b> 🧚𝘼𝙈𝘼𝙕𝙊𝙉𝙀 𝘼𝙇𝙀𝙓𝘼 (ᴠɪᴘ)  </b></h1>


</p>

<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com/?lines=Welcome+to+Amazone+Alexa&font=Fira%20Code&center=true&width=380&height=50">
</p>
</a>
Project of  🧚Amazone - Makes it easy and fun to use Whatsapp. Also first Made in sri lanka userbot for Whatsapp.

<a href="https://chat.whatsapp.com/GTgqgMTo7FoJ1GqdijshsX">Support Group</a> |
        <a href="https://Wa.me/+94766598862">ChethanaBro Whatsapp </a> |
  
`<Enjoy & stay safe stay home>`
</p>

</a>
<p align="center">
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/docker/pulls/xneon2/Hashzi-X?style=flat-square"/></a>
  </a>
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square">
    
  </a>

</p>

<p align="center">
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fxneon2%2FHashzi-X&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/xneon2/Hashzi-X/fork">
    <img src="https://img.shields.io/github/forks/xneon2/Hashzi-X?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/xneon2/Hashzi-X/stargazers">
    <img src="https://img.shields.io/github/stars/xneon2/Hashzi-X?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Boyutu&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/blob/master/LICENSE">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy">
    <img src="https://img.shields.io/static/v1?label=Author&message=Neotro%20X&color=purple&style=plastic">

  </a>
  <a href="https://wa.me/94786598862">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Teenuh%20AX%20-purple&style=plastic">

  </a>
</p>

## 💡Setup 

### Simple method 

#### You can easily get the QR code Repl.it .. Click the button below
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@tenuh/Alexa?v=1)

`You need 2 mobile phones to build the Neotro-x  bot!
You will run the bot from the second device.
You will only generate a QR code with the first device.
From the first device you need to install Neotro-x  Bot.`

#### After getting the QR code, click the button below to apply the bot...
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/xneon2/AMAZON-BETA)


> [Sinhala Youtube Tutorial](https://www.youtube.com/watch?v=mcEeIspWOpY&ab_channel=UC8yo_BwOJs9cLfYVHewPC6Q)

> [![Sinhala Youtube Tutorial](https://img.youtube.com/vi/mcEeIspWOpY/0.jpg)](https://www.youtube.com/watch?v=mcEeIspWOpY)

# 🚀Amazone Alexa
🦹‍♀️Here is the Amazone  bot features

<a href="https://gist.github.com/xneon2/ff9aa739e8c1399d05c79db1dab9ee4c">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">
  
  </a>

🦹‍♀️Here is the Alexa  Command list

<a href="https://gist.github.com/xneon2/86f619bc49691abb73546819754e1b94">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>

## F.A.Q
Answer a few frequently asked questions;
### Can you read my messages???
Since this project is open source, all codes are clear. Not more or less; You can see what you want. **Your accounts are not accessible.**

### 🔒What about our security?
If you are concerned about security, you can install it on your own computer. If you think someone else has taken over your data, **Whatsapp> Three Dots> Whatsapp Web> Logout**.

### 💰Do these bots have to pay??
**Of course not.** It never happens. But you can donate to us. You can reach me via [Whatsapp](https://wa.me/94766598862) 

### 🔄 Can I Edit this bot?

**As per the license, You Can** But We Will Not Support. 🙃

### ❔ How many features/commands are there in this bot?

There are **100+** Features/Commands Are there in **this bot!**

### ⚠️ Warning! 
```
Due to Userbot; Your WhatsApp account may be banned.
This is an open source project, you are responsible for everything you do. 
Absolutely, alexa  executives do not accept responsibility.
By establishing the alexa, you are deemed to have accepted these responsibilities.
```

## 👨‍💻Developer

[![Chethana_Broh-TeenuhX](https://github.com/tenuh.png?size=100)](https://https://youtu.be/mcEeIspWOpY)

( Chethana_Bro(Teenuh-X😈)
<a href="https://Wa.me/+94766598862">
    <img src="https://img.shields.io/badge/FindOn%20whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+14382551507">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+17722181933">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+17723534981">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

[![Telegram](https://img.shields.io/badge/FindOn-Telegram-green.svg)](https://t.me/@tharun_003)
[![Instergram](https://img.shields.io/badge/FindOn-Instergram-green.svg)](https://instergram.com/tharun_003)
[![Find On Whatsapp ](https://img.shields.io/badge/Findon-whatsapp-red.svg)](https://Wa.me/+94766598862)


### 🚀Amazone Alexa Team

[![Find On Telegram ](https://img.shields.io/badge/Ramilka-Rodrigo-blue.svg)](https://t.me/ramiya_yt) [![Encuizer ](https://img.shields.io/badge/En-Cuizer-blue.svg)](https://Wa.me/+94725549179) [![Find On Whatsapp ](https://img.shields.io/badge/Chamee-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Hazel-Safron-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Rashid-Riyaz-blue.svg)](https://Wa.me/+17723534981) [![Find On Whatsapp ](https://img.shields.io/badge/mr.freez-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Lithira-Ranahansika-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Lucifer-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Akash-thevidu-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Josh-Mardown-blue.svg)](https://Wa.me/)

## 👽Thanks To
[![Yusuf Usta](https://github.com/yusufusta.png?size=50)](https://t.me/fusufs)
[Yusuf Usta](https://t.me/fusufs)
