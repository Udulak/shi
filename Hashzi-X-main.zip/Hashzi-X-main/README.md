#### © Select your language
  [![English](https://img.shields.io/badge/Select-English-red.svg)](https://github.com/xneon2/Hashzi-X/blob/main/README-SI.md)
  [![Sinhala](https://img.shields.io/badge/Select-Sinhala-green.svg)](https://github.com/xneon2/Hashzi-X/blob/main/README.md)
    
</a>          


</a>

![logo](https://telegra.ph/file/702bfc5e4176727a34559.jpg)
<h1 align="center"><b> 🧚𝗔𝗠𝗔𝗭𝗢𝗡𝗘 𝗔𝗟𝗘𝗫𝗔 (ᴠɪᴘ) </b></h1>

</a>
             
<p align="center">
  <img src="https://readme-typing-svg.herokuapp.com/?lines=Welcome+to+Amazone+Alexa&font=Fira%20Code&center=true&width=380&height=50">

</a>
<p align="center">
    Project of  🧚Amazone Alexa🪐 - යනු භාවිතය පහසු හා ලේසියෙන් සාදාගත හැකි Whatsapp රොබෝවෙකි. AMAZONE-Alexa යනු ලංකාවෙ පළවෙනි සිංහල whatsapp රොබෝව වේ..🇱🇰
    <br>
        <a href="https://chat.whatsapp.com/GTgqgMTo7FoJ1GqdijshsX">Support Group</a> |
        <a href="https://Wa.me/+94766598862">ChethanaBro Whatsapp </a> |
   </a>    
        
  <p align="center">
<a href="https://t.me/Bot_x_whatsapp"><img title="Author" src="https://img.shields.io/badge/BOT NEWS-CHANEL-/JulieMwol?color=blue&style=for-the-badge&logo=telegram"></a>
</p>
   </a>
</p>
<p align="center">
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/docker/pulls/fusuf/whatsasena?style=flat-square"/></a>
  
  </a>
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/docker/image-size/fusuf/whatsasena?style=flat-square">
    
  </a>
</p>

<p align="center">
  <a href="https://github.com/xneon2/Hashzi-X">
    <img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2Fxneon2%2FHashzi-X&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false" alt="Views"/></a>
  
  </a>
  <a href="https://github.com/xneon2/Hashzi-X/fork">
    <img src="https://img.shields.io/github/forks/xneon2/Hashzi-X?label=Fork&style=social">
    
  </a>
  <a href="https://github.com/xneon2/Hashzi-X/stargazers">
    <img src="https://img.shields.io/github/stars/xneon2/Hashzi-X?style=social">
  </a>
</p>

<p align="center">
  <a href="httsp://github.com/xneon2/Hashzi-X">
    <img src="https://img.shields.io/github/repo-size/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Repo%20Boyutu&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated/blob/master/LICENSE">
    <img src="https://img.shields.io/github/license/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=License&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy/WhatsAsenaDuplicated">
    <img src="https://img.shields.io/github/languages/top/phaticusthiccy/WhatsAsenaDuplicated?color=purple&label=Javascript&style=plastic">

  </a>
  <a href="https://github.com/phaticusthiccy">
    <img src="https://img.shields.io/static/v1?label=Author&message=Neotro%20X&color=purple&style=plastic">

  </a>
  <a href="https://wa.me/94786598862">
    <img src="https://img.shields.io/badge/Contact%20Me%20On%20Whatsapp-Teenuh%20AX%20-purple&style=plastic">

  </a>
</p>

### 👩‍🦰ක්‍රියාත්මක කරන්නෙ කෙසේද??

#### සරල ක්‍රමය

#### ඔබට පහසුවෙන්ම Repl.it මඟින් QR ගන්න පුලුවන්..පහල  බටනය භාවිත කරන්න
[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@tenuh/Alexa?v=1)


#### Termux මඟින් ලබාගන්න
```
bash <(curl -L https://tinyurl.com/ALEXA-session) 
```
##### ඉහත කේතය Copy කරගෙන termux එකෙ paste කරලා Run කරන්න.

### [NOTE ❓]
```
Amazone Alexa bot ගොඩනැගීමට ඔබට ජංගම දුරකථන 2 ක් අවශ්‍ය වේ!
ඔබ දෙවන උපාංගයෙන් bot ක්‍රියා කරනු ඇත. 
ඔබ පළමු උපාංගය සමඟ පමණක් QR කේතය generate කරනු ඇත.
පළමු උපාංගයෙන් ඔබට Amazone Bot install කිරීමට අවශ්‍යයි..
```
#### QR කේතය ලබා ගත් පසු පහල බටනය ඔබලා Bot deploy කරන්න
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/xneon2/Hashzi-X)


> [සම්පූර්ණ සිංහල Tutorial](https://www.youtube.com/watch?v=mcEeIspWOpY&ab_channel=UC8yo_BwOJs9cLfYVHewPC6Q)

> [![සම්පූර්ණ සිංහල Tutorial](https://img.youtube.com/vi/mcEeIspWOpY/0.jpg)](https://www.youtube.com/watch?v=mcEeIspWOpY)

# 🚀Amazone පහසුකම් ලැයිස්තුව

<a href="https://gist.github.com/xneon2/ff9aa739e8c1399d05c79db1dab9ee4c">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">
  
  </a>

මෙන්න සම්පූර්ණ විධාන ලැයිස්තුව

<a href="https://gist.github.com/xneon2/61e9205076afa540fc1d5f7a6f467bd1">
    <img src="https://img.shields.io/badge/Click%20here-purple&style=plastic">

  </a>

## 🚀F.A.Q
නිතර අසන ප්‍රශ්න කිහිපයකට පිළිතුරු සපයන්න;

### ඔබට මගේ පණිවිඩ කියවිය හැකිද??
මෙම ව්‍යාපෘතිය විවෘත කේතයක් බැවින් සියලු කේත පැහැදිලි වේ. අඩු හෝ වැඩි නොවේ; ඔබට අවශ්‍ය දේ බැලීමට ඔබට හැකිය. **අපට ඔබගේ ගිණුම් වලට ප්‍රවේශයක් නොමැත.**

### 🔒අපේ ආරක්ෂාව ගැන කුමක් කිව හැකිද?
ඔබ ආරක්ෂාව ගැන සැලකිලිමත් වන්නේ නම්, ඔබට එය ඔබේම පරිගණකයකින් install කළ හැකිය. වෙනත් අයෙකු ඔබගේ දත්ත ග්‍රහණය කර ගෙන ඇතැයි ඔබ සිතන්නේ නම්, **Whatsapp> Three Dots> Whatsapp Web> Logout**.

### 💰මෙම බොට් ගෙවිය යුතුද?
**ඇත්ත වශයෙන්ම නැත.*** එය කිසි විටෙකත් සිදු නොවේ. නමුත් ඔබට අපට donation කළ හැකිය. You can reach me via [Whatsapp](https://wa.me/+94766598862) .

### ❓ඔබට මෙය නැවත සංස්කරණය කළ හැකිද??
***අනිවාර්යයෙන් ඔබට හැකියි.*** නමුත් අපෙන් ඔබට කිසිදු සහයක් නොමැත.

### ⚠️ Warning! 
```
පරිශීලක බොට් නිසා; ඔබගේ WhatsApp ගිණුම banned කළ හැකිය.
මෙය විවෘත මූලාශ්‍ර ව්‍යාපෘතියකි, ඔබ කරන සෑම දෙයකටම ඔබ වගකිව යුතුය. 
නියත වශයෙන්ම,Neotro-x  විධායකයන් වගකීම භාර නොගනී.
neotro-x  පිහිටුවීමෙන් ඔබ මෙම වගකීම් භාරගෙන ඇති බව සලකනු ලැබේ.
```

## 👨‍💻Developer

[![Chethana_Broh-TeenuhX](https://github.com/tenuh.png?size=100)](https://https://youtu.be/mcEeIspWOpY)

 ***ᴄʜᴇᴛʜᴀɴᴀ_ʙʀᴏ(Teenuh-X😈)***
<a href="https://Wa.me/+94766598862">
    <img src="https://img.shields.io/badge/FindOn%20whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+14382551507">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+17722181933">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

<a href="https://Wa.me/+17723534981">
    <img src="https://img.shields.io/badge/FindOn%20Whatsapp-purple&style=plastic">
  
  </a>

[![Telegram](https://img.shields.io/badge/FindOn-Telegram-green.svg)](https://t.me/@tharun_003)
[![Instergram](https://img.shields.io/badge/FindOn-Instergram-green.svg)](https://instergram.com/tharun_003)
[![Find On Whatsapp ](https://img.shields.io/badge/Findon-whatsapp-red.svg)](https://Wa.me/+94766598862)


### 🚀Amazone Alexa Team

[![Find On Telegram ](https://img.shields.io/badge/Ramilka-Rodrigo-blue.svg)](https://t.me/ramiya_yt) [![Encuizer ](https://img.shields.io/badge/En-Cuizer-blue.svg)](https://Wa.me/+94725549179) [![Find On Whatsapp ](https://img.shields.io/badge/Chamee-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Hazel-Safron-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Rashid-Riyaz-blue.svg)](https://Wa.me/+17723534981) [![Find On Whatsapp ](https://img.shields.io/badge/mr.freez-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Lithira-Ransika-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Lucifer-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Akash-thevidu-blue.svg)](https://Wa.me/) [![Find On Whatsapp ](https://img.shields.io/badge/Josh-Mardown-blue.svg)](https://Wa.me/)
[![Find On Whatsapp ](https://img.shields.io/badge/Ganster-blue.svg)](https://Wa.me/)
### 📑Amozon Support Groups

[![Find On Whatsapp ](https://img.shields.io/badge/Amazon-Plugins-red.svg)](https://chat.whatsapp.com/JJs2iwfF0VKL3IWrIyr7AT)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazone-Support01-blue.svg)](https://chat.whatsapp.com/GTgqgMTo7FoJ1GqdijshsX)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazone-Support02-blue.svg)](https://chat.whatsapp.com/K4QouGNrNcm1iARgDaYiLj)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazone-Support03-blue.svg)](https://chat.whatsapp.com/DSX2aegJpVRG3cWIUlBa48)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazome-News01-purple.svg)](https://chat.whatsapp.com/LuLTEKm22fp8gv4ltCmKMo)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazone-News02-purple.svg)](https://chat.whatsapp.com/LVykTrmNEU98AktU0eBNNq)
[![Find On Whatsapp ](https://img.shields.io/badge/Amazone-News03-purple.svg)](https://chat.whatsapp.com/JdNWV3viiGKGINYNrb5oy8)
## 👽Thanks To
[![Yusuf Usta](https://github.com/yusufusta.png?size=50)](https://t.me/fusufs)
[Yusuf Usta](https://t.me/fusufs)
